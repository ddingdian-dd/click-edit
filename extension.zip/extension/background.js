chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (changeInfo.status !== 'complete') return

  const result = await chrome.storage.session.get(`vpe_${tabId}`)
  if (!result[`vpe_${tabId}`]) return

  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      files: ['content.js']
    })
  } catch {}
})
